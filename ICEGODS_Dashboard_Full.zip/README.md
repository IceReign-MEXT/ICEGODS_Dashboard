# ICEGODS_Dashboard

🚀 A blockchain defense & monitoring dashboard.  
This project combines automated bots, analytics, and a real-time interface to protect wallets and detect threats.

---

## 📂 Project Structure
