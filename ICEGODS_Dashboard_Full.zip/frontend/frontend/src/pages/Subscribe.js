import React from "react";
import ReactDOM from "react-dom";
import Subscribe from "./pages/Subscribe";

ReactDOM.render(
  <React.StrictMode>
    <Subscribe />
  </React.StrictMode>,
  document.getElementById("root")
);
